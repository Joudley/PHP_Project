<?php

function Connect(){
    $dns ="mysql:host=localhost;dbname=projet";
    $user = "root";
    $pswd = "";
    try{
        $con = new PDO($dns,$user,$pswd);
        if($con)
        return $con;
    }catch(PDOException $e){
        die("Erreur :".$e->getmessage());    
    }
}




?>