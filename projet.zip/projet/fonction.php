<?php
    include_once("connect.php");
    function util($sql,$type_exc){
        
        try{
            $sql = $sql;
            $con = Connect();
            if($type_exc =="exec")
            {  
                $sql_exec = $con->exec($sql);
                return $sql_exec;
            }
            else {
                # code...
                $sql_exec = $con->query($sql);
                return $sql_exec;
            }

        }catch(PDOException $e){
            die("Erreur :".$e->getmessage());
        }
    }

    function Insert_patient($idpatient,$nom,$prenom,$sexe,$date_naissance,$telephone,$adresse,$age,$nomjeunefillemere)
    {        
        $sql = "INSERT INTO patient(idpatient,nom,prenom,sexe,date_naissance,telephone,adresse,age,nomjeunefillemere) VALUES('$idpatient','$nom','$prenom','$sexe','$date_naissance','$telephone','$adresse','$age','$nomjeunefillemere')";
        $exec_sql=util($sql,"exec");
        //echo "Patient enregistrer avec succes";
       
    }

    function Update_patient($idpatient,$nom,$prenom,$sexe,$date_naissance,$telephone,$adresse,$age,$nomjeunefillemere)
    {
        $sql = "UPDATE `patient` SET `nom`='$nom',`prenom`='$prenom',`sexe`='$sexe',`date_naissance`='$date_naissance',`telephone`=$telephone,`adresse`=$adresse,`age`=$age,`nomjeunefillemere`=$nomjeunefillemere WHERE `idpatient`='$idpatient'";
        $exec_sql=util($sql,"exec");
       
    }

    function Delete_patient($idpatient)
    {      
        $sql = "DELETE FROM `patient` WHERE `idpatient`='$idpatient'";
        $exec_sql=util($sql,"exec");
        
    }

    function Select_all_patient()
    {
       
           $sql = "SELECT * FROM `patient`";
          $exec_sql = util($sql,"query");
          $r=[];
            while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
                # code...
                array_push($r,$l);
            }
       return $r;
    }

    function Select_code_patient($idpatient)
    {        
        $sql = "SELECT * FROM `patient` WHERE `idpatient`=$idpatient";
        $exec_sql = util($sql,"query");
        while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
            # code...
            return $l; 
        }
       
    }

    function Insert_prescription($idconsultation,$ordonnance)
    {
        $sql = "INSERT INTO `prescription`(`idconsultation`, `ordonnance`) VALUES ('$idconsultation','$ordonnance')";
        $exec_sql=util($sql,"exec");
    }

    function Select_code_prescription($idconsultation)
    {        
        $sql = "SELECT * FROM `prescription` WHERE `idconsultation`=$idconsultation";
        $exec_sql = util($sql,"query");
           while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
               # code...
               print_r($l);
           }
       
    }

    function Select_all_prescription()
    {
       
           $sql = "SELECT * FROM `prescription`";
          $exec_sql = util($sql,"query");
          $r=[];
          while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
              # code...
              array_push($r,$l);
          }
     return $r;
           
       
    }

    
    function INSERT_consultation($idconsultation,$no_dossier,$idmedecin,$symptome,$date_consultation)
    {
    $sql = "INSERT INTO consultation(idconsultation,no_dossier,idmedecin,symptome,date_consultation) VALUES ('$idconsultation','$no_dossier','$idmedecin','$symptome','$date_consultation')";
    $exec_sql=util($sql,"exec");
    }

    
    function Select_code_consultation($idconsultation)
    {        
        $sql = "SELECT * FROM `consultation` WHERE `idconsultation`=$idconsultation";
        $exec_sql = util($sql,"query");
           while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
               # code...
               print_r($l);
           }
       
    }

    function Select_all_consultation()
    {
       
           $sql = "SELECT * FROM `consultation`";
          $exec_sql = util($sql,"query");
          $r=[];
          while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
              # code...
              array_push($r,$l);
          }
     return $r;
       
    }



    function INSERT_dossier($no_dossier,$idpatient)
    {
    $sql = "INSERT INTO `dossier`(`no_dossier`, `idpatient`) VALUES ('$no_dossier','$idpatient')";
    $exec_sql=util($sql,"exec");
    }

    
    function Select_code_dossier($no_dossier)
    {        
        $sql = "SELECT * FROM `dossier` WHERE `no_dossier`=$no_dossier";
        $exec_sql = util($sql,"query");
           while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
               # code...
               print_r($l);
           }
       
    }

    function Select_all_dossier()
    {
       
           $sql = "SELECT * FROM `dossier`";
          $exec_sql = util($sql,"query");
            while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
                # code...
                print_r($l);
            }
           
       
    }
    
    

    function Insert_medecin($idmedecin,$nom,$prenom,$sexe,$adresse,$telephone,$email,$specialisation)
    {        
        $sql = "INSERT INTO medecin(idmedecin,nom,prenom,sexe,adresse,telephone,email,specialisation) VALUES('$idmedecin','$nom','$prenom','$sexe','$adresse','$telephone','$email','$specialisation')";
        $exec_sql=util($sql,"exec");
    }

    function Update_medecin($idmedecin,$nom,$prenom,$sexe,$adresse,$telephone,$email,$specialisation)
    {
        $sql = "UPDATE `medecin` SET `nom`='$nom',`prenom`='$prenom',`sexe`='$sexe',`adresse`='$adresse',`telephone`=$telephone,`email`=$email,`specialisation`=$specialisation WHERE `idmedecin`='$idmedecin'";
        $exec_sql=util($sql,"exec");
    }

    function Delete_medecin()
    {      
        $sql = "DELETE FROM `medecin` WHERE `idmedecin`='$idmedecin'";
        $exec_sql=util($sql,"exec");
    }

    function Select_all_medecin()
    {
       
           $sql = "SELECT * FROM `medecin`";
          $exec_sql = util($sql,"query");
          $r=[];
          while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
              # code...
              array_push($r,$l);
          }
     return $r;
       
    }

    function Select_code_medecin($idmedecin)
    {        
        $sql = "SELECT * FROM `medecin` WHERE `idmedecin`=$idmedecin";
        $exec_sql = util($sql,"query");
        while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
            # code...
            return $l;
        }
    }

    
    function Select_code_med($idmedecin)
    {        
        $sql = "SELECT * FROM `consultation` WHERE `idmedecin`=$idmedecin";
        $exec_sql = util($sql,"query");
        $r=[];
        while ($l = $exec_sql->fetch(PDO::FETCH_ASSOC)) {
            # code...
            array_push($r,$l);
        }
   return $r;
    }



   ?>




