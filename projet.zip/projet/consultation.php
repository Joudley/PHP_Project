<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Consultation</title>
</head>
<body class="bg-image fs-4" style="
      background-image: url('hospi2.jpg'); repeat:no-repeat;
      width:100%;
    ">
<header class="bg-success text-light p-3" style="position:relative;">
<a href="index.php" class="btn btn-info" style="position:absolute;top:20px;left:20px;">Retour</a>
<div class="text-center">
  <H1>CLINIQUE BON SERVICE</H1>
  <h2>La solution a vos besoins sanitaires</h2>
</div>
</header>

<h2 class="text-dark text-center">Enregistrement d'une consultation</h2>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-6">
        <form action="consultation.php"  method="post">

<div class="form-group">

            <label for="" class="form-label">Id consultation</label>
            <input type="number" class="form-control" name="idconsultation" id="idconsultation" placeholder="id du consultation"> <br>

            <label for="" class="form-label">Numero du dossier</label>
            <input type="number" class="form-control" name="nodossier" id="" placeholder="Numero du dossier">  <br>

            <label for="" class="form-label">Id du medecin</label>
            <input type="number" class="form-control" name="idmedecin" id="" placeholder="id du medecin">  <br>

            <label for="" class="form-label">Symptome du patient</label>
            <input type="text" class="form-control" name="symptome" id="" placeholder="Symptome du patient">  <br>

            <label for="" class="form-label">Date de consultation</label>
            <input type="text" class="form-control" name="date_consultation" id="" placeholder="Date de consultation">  <br>

            <div class="mt-3">
            <input type="submit" class="btn-secondary" value="Enregistrer" name="bt_save">   
        </div>

        </form>

        </div>
    </div>
</div>





    <?php


require("fonction.php");
 if(isset($_POST['bt_save'])){
    $idconsultation=$_POST["idconsultation"];
    $no_dossier=$_POST["nodossier"];
    $medecin=$_POST["idmedecin"];
    $symptome=$_POST["symptome"];
    $date=$_POST["date_consultation"];
    if($idconsultation!="" && $no_dossier!="" && $medecin!="" && $symptome!="" && $date!=""){
    Insert_consultation($idconsultation,$no_dossier,$medecin,$symptome,$date);
    echo"<script>alert(\"Consultation enregistre avec succes\")</script>";
        }else{
            echo"<script>alert(\"Faut remplir toutes le cases\")</script>";
        }
        
 }

 ?>


</div>    



</body>
</html>