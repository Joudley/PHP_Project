<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Rechercher un medecin</title>
</head>
<body class="text-center bg-secondary ">
<header class="bg-success text-light p-3" style="position:relative;">
<a href="index.php" class="btn btn-info" style="position:absolute;top:20px;left:20px;">Retour</a>
<div>
  <H1>CLINIQUE BON SERVICE</H1>
  <h2>La solution a vos besoins sanitaires</h2>
</div>
</header>

    <form action="rechercher_medecin.php" method="post">

    <div class="form-group">
    <label for="idmedecin" class="m-2 text-dark">Id du medecin a rechercher</label>
    <input type="text" name="idmedecin" id="">
    <input type="submit" name="recherche" value="Rechercher">
    </div>
    </form>
    <?php
    require("fonction.php");
    if(isset($_POST["recherche"])){
$id=$_POST["idmedecin"];
$resultat=Select_code_medecin($id);
echo"<table class=\"table table-striped table-secondary text-dark\">";
           echo"<thead>
           <tr>
           <th scope=\"col\">id du medecin  </th>
           <th scope=\"col\">Nom </th>
           <th scope=\"col\">Prenom  </th>
           <th scope=\"col\">Sexe  </th>
           <th scope=\"col\">Adresse  </th>
           <th scope=\"col\">Telephone  </th>
           <th scope=\"col\">Email </th>
           <th scope=\"col\">Specialite </th>
           </tr>
         </thead>";
           echo"<tbody>";
           foreach($resultat as $e){
               echo"<td>$e</td>";
           }
        
           echo"</tbody></table>";



    }
    ?>
</body>
</html>