<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <title>Page d'acceuil</title>
</head>
<body class="bg-image text-center" style="
      background-image: url('hospi.jpg'); repeat:no-repeat;
      width:100%;
    ">
<header class="bg-image text-light" style="
      background-image: url('hospi4.jpg'); repeat:no-repeat;
      height: 400px;
      width:100%;
    " >
    <br>
    <br>
<H1>BIENVENUE A LA CLINIQUE BON SERVICE</H1>
<br>
<h2>La solution a vos besoins sanitaires</h2>
</header>

<nav class="navbar navbar-light text-center ">

<div style="width:50%; float:left">
<div>
<form action="patient.php" method="post">
    
    <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Enregistrer un patient" name="bt_new">
    </form>
    </div>

    <div>
    <form action="dossier_1patient.php" method="post">
     <input type="submit" class="btn btn-secondary m-2" style="width:80%"  value="Creer un dossier pour un patient" name="bt_sa">
     </form>
    </div>
    


    <div>
    <form action="consultation.php" method="post">
     <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Enregistrer une consultation" name="bt_sv"> 
     </form>
    </div>
    


    <div>
    <form action="prescription.php" method="post">
     <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Enregistrer une prescription" name="bt_sved">
     </form>
    </div>
    

    <div>
    <form action="rechercher_patient.php" method="post">
     <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Rechercher un patient" name="bt_search"> 
     </form>
    </div>
    

     <div>
     <form action="medecin.php" method="post">
     <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Enregistrer un medecin" name="bt_save">  
     </form>
     </div>

     </div>

  <div style="width:50%; float:right">
  <div>
     <form action="rechercher_medecin.php" method="post">

     <input type="submit" class="btn btn-secondary m-2 " style="width:80%" value="Rechercher un medecin" name="bt_search">
     </form>
     </div>
     <div>
     <form action="liste_medecin.php" method="post">

     <input type="submit" class="btn btn-secondary m-2 " style="width:80%" value="Liste des medecins" name="bt_search">
     </form>
     </div>

    <div>
     <form action="liste_patient.php" method="post">
    <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Liste des patients" name="bt_search_all">
     </form>
     </div>
 <div>
     <form action="liste_consultation.php" method="post">
  <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Liste des consultations" name="bt_search_all"> 
     </form>
     </div>

 <div>
     <form action="liste_prescription.php" method="post">
    <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Liste des prescriptions" name="bt_search_all">
     </form>
     </div>
    
     <div>
     <form action="liste_cons_med.php" method="post">
     <input type="submit" class="btn btn-secondary m-2" style="width:80%" value="Liste des consultations d'un medecin" name="bt_search_all">
     </form>
     </div>
  </div>
     </nav>

    
</body>
</html>