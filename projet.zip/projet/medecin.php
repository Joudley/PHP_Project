<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Enregistrement d'un medecin</title>
</head>
<body class="bg-image fs-4" style="
      background-image: url('hospi2.jpg'); repeat:no-repeat;
      width:100%;
    ">
<header class="bg-success text-light p-3" style="position:relative;">
<a href="index.php" class="btn btn-info" style="position:absolute;top:20px;left:20px;">Retour</a>
<div class="text-center">
  <H1>CLINIQUE BON SERVICE</H1>
  <h2>La solution a vos besoins sanitaires</h2>
</div>
</header>

<h2 class="text-dark text-center">Remplir le formulaire du medecin</h2>

<div class="container">
    <div class="row justify-content-center">
    <div class="col-6">
    <form action="medecin.php"  method="post">

<div class="form-group">

            <label for=""class="form-label">id du medecin</label>
            <input type="number" class="form-control" name="idmedecin" id="idmedecin" placeholder="id du medecin"> <br>

            <label for=""class="form-label">Nom</label>
            <input type="text" class="form-control" name="nom" id="" placeholder="Entrez votre nom">  <br>

            <label for=""class="form-label">Prenom</label>
            <input type="text" class="form-control" name="prenom" id="" placeholder="Entrez votre prenom">  <br>

            <label for="" class="form-label">Sexe</label>
            <input type="radio" class="" name="sexe" id="" checked value="Masculin" > Masculin 
            <input type="radio" class="" name="sexe" id="" value="Feminin"> Feminin <br>

            <label for=""class="form-label">Adresse</label>
            <input type="text" class="form-control" name="adresse" id="" placeholder="Entrez votre adresse">  <br>

            <label for=""class="form-label">Telephone</label>
            <input type="text" class="form-control" name="tel" id="" placeholder="Entrez votre telephone">  <br>

            <label for=""class="form-label">Email</label>
            <input type="text" class="form-control" name="email" id="" placeholder="Entrez votre email">  <br>

            <label for=""class="form-label">Specialisation</label>
            <input type="text" class="form-control" name="specialisation" id="" placeholder="Entrez votre specialisation">  <br>

</div>    



<div class="mt-3">
            <input type="submit" class="btn btn-info" value="Enregistrer" name="bt_sav">   
        </div>

</form>
    </div>
    </div>
</div>

<?php
require("fonction.php");
 if(isset($_POST["bt_sav"])){
    $idmedecin=$_POST["idmedecin"];
    $nom=$_POST["nom"];
    $prenom=$_POST["prenom"];
    $sexe=$_POST["sexe"];
    $adresse=$_POST["adresse"];
    $tel=$_POST["tel"];
    $email=$_POST["email"];
    $specialisation=$_POST["specialisation"];
    if($idmedecin !="" && $nom!="" && $prenom!="" && $sexe!="" && $adresse!="" && $tel!="" && $email!="" && $specialisation!=""){
    Insert_medecin($idmedecin,$nom,$prenom,$sexe,$adresse,$tel,$email,$specialisation);
    echo"<script>alert(\"Medecin enregistre avec succes\")</script>";
}else{
    echo"<script>alert(\"Faut remplir toutes le cases\")</script>";
}
 }

?>

</body>
</html>