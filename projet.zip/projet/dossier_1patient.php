<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Dossier d'un patient</title>
</head>
<body class="bg-image fs-4" style="
      background-image: url('hospi2.jpg'); repeat:no-repeat;
      width:100%;
    ">
<header class="bg-success text-light p-3" style="position:relative;">
<a href="index.php" class="btn btn-info" style="position:absolute;top:20px;left:20px;">Retour</a>
<div class="text-center">
  <H1>CLINIQUE BON SERVICE</H1>
  <h2>La solution a vos besoins sanitaires</h2>
</div>
</header>


<h2 class="text-dark text-center mt-4">Creer un dossier pour un Patient</h2>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-6">
            <form action="dossier_1patient.php"  method="post">

            <div class="form-group">

                        <label for="" class="m-2 form-label">Numero du dossier</label>
                        <input type="number" class="form-control" name="no_dossier" id="no_dossier" placeholder="Numero du dossier"> <br>

                        <label for="" class="m-2 form-label">id patient</label>
                        <input type="number" class="form-control" name="idpatient" id="" placeholder="Id du patient">  <br>

                        
            <div class="mt-3">
                        <input type="submit" class="btn-info" value="Enregistrer" name="bt_save">   
                    </div>

                    
            </div>    

            </form>
        </div>
       
    </div>
</div>

<?php

require("fonction.php");
 if(isset($_POST['bt_save'])){
    $no_dossier=$_POST["no_dossier"];
    $id=$_POST["idpatient"];
    if($no_dossier !="" && $id !=""){
    INSERT_dossier($no_dossier,$id);
    echo"<script>alert(\"Dossier enregistre avec succes\")</script>";
        }else{
            echo"<script>alert(\"Faut remplir toutes le cases\")</script>";
        }
        
 }
 ?>

</body>
</html>