<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enregistrement d'un patient</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body class="bg-image fs-4" style="
      background-image: url('hospi2.jpg'); repeat:no-repeat;
      width:100%;
    ">
<header class="bg-success text-light p-3" style="position:relative;">
<a href="index.php" class="btn btn-info" style="position:absolute;top:20px;left:20px;">Retour</a>
<div class="text-center">
  <H1>CLINIQUE BON SERVICE</H1>
  <h2>La solution a vos besoins sanitaires</h2>
</div>
</header>


<h2 class="text-dark text-center">Remplir le formulaire du Patient</h2>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-6">
                    <form action="patient.php"  method ="post">

            <div class="form-group">

                        <label for="" class="form-label">id patient</label>
                        <input type="number" class="form-control" name="id" id="idpatient" placeholder="Id du patient"> <br>

                        <label for="" class="form-label">Nom</label>
                        <input type="text" class="form-control" name="nom" id="" placeholder="Entrez votre nom">  <br>

                        <label for="" class="form-label">Prenom</label>
                        <input type="text" class="form-control" name="prenom" id="" placeholder="Entrez votre prenom">  <br>

                        <label for="" class="form-label">Sexe</label>
                        <input type="radio" class="" name="sexe" id="" checked value="Masculin" > Masculin 
                        <input type="radio" class="" name="sexe" id="" value="Feminin"> Feminin <br>

                        <label for="" class="form-label">Date de naissance</label>
                        <input type="text" class="form-control" name="naissance" id="" placeholder="Entrez votre date de naissance">  <br>

                        <label for="" class="form-label">Telephone</label>
                        <input type="text" class="form-control" name="tel" id="" placeholder="Entrez votre telephone">  <br>

                        <label for="" class="form-label">Adresse</label>
                        <input type="text" class="form-control" name="adresse" id="" placeholder="Entrez votre adresse">  <br>

                        <label for="" class="form-label">Age</label>
                        <input type="number" class="form-control" name="age" id="" placeholder="Entrez votre age">  <br>

                        <label for="" class="form-label">Nom de jeune fille mere</label>
                        <input type="text" class="form-control" name="jeune" id="" placeholder="Entrez votre nom de jeune fille mere">  <br>
            </div>    



            <div class="mt-3">
                        <input type="submit" class="btn-info" value="Enregistrer" name="bt_save">   
                    </div>

            </form>
        </div>
    </div>
    
</div>
<?php
require("fonction.php");
 if(isset($_POST['bt_save'])){
    $id=$_POST["id"];
    $nom=$_POST["nom"];
    $prenom=$_POST["prenom"];
    $sexe=$_POST["sexe"];
    $naissance=$_POST["naissance"];
    $tel=$_POST["tel"];
    $adresse=$_POST["adresse"];
    $age=$_POST["age"];
    $jeune=$_POST["jeune"];
   if ($id!="" && $nom!="" && $prenom!="" && $sexe!="" && $naissance!="" && $tel!="" && $adresse!="" && $age!="" && $jeune!="") {
    Insert_patient($id,$nom,$prenom,$sexe,$naissance,$tel,$adresse,$age,$jeune);
        echo"<script>alert(\"Patient enregistre avec succes\")</script>";
   }else{
       echo"<script>alert(\"Faut remplir toutes le cases\")</script>";
   }
       
    }
 
 
?>

</body>
</html>