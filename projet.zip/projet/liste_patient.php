<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Liste des patients</title>
</head>
<body class="text-center bg-secondary ">
<header class="bg-success text-light p-3" style="position:relative;">
<a href="index.php" class="btn btn-info" style="position:absolute;top:20px;left:20px;">Retour</a>
<div>
  <H1>CLINIQUE BON SERVICE</H1>
  <h2>La solution a vos besoins sanitaires</h2>
</div>
</header>

<div class="text-center">
<h1 class="text-dark">Liste des patients de la clinique </h1>
</div>
    <!-- <form action="liste_patient.php" method="post"> -->
    <!-- <label for="idpatient">Liste des patients</label> <br> -->
    <!-- <input type="submit" name="liste" value="Liste"> -->
    <!-- </form> -->
    <?php
    require("fonction.php");
    // if(isset($_POST["liste"])){
        $resultat=Select_all_patient();
        echo"<table class=\"table table-striped table-secondary text-dark\">";
           echo"<thead>
           <tr>
             <th scope=\"col\">id du patient  </th>
             <th scope=\"col\">Nom  </th>
             <th scope=\"col\">Prenom  </th>
             <th scope=\"col\">Sexe  </th>
             <th scope=\"col\">Date de naissansce  </th>
             <th scope=\"col\">Telephone  </th>
             <th scope=\"col\">Adresse  </th>
             <th scope=\"col\">Age  </th>
             <th scope=\"col\">Nom jeune fille mere  </th>
           </tr>
         </thead>";
           echo"<tbody>";
           foreach($resultat as $e){
               echo"<tr>";
               foreach($e as $t){
               echo"<td>$t</td>";
           }
           echo"</tr>";
        }
           echo"</tbody></table>";
    // }
    ?>
</body>
</html>